package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Elementos de la interfaz
    private EditText etInput;
    private RadioGroup rgType;
    private TextView tvResult;

    // Constantes para almacenamiento en SharedPreferences
    private static final String PREFS_NAME = "ConversorPrefs";
    private static final String KEY_LAST = "last_conversion";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Carga el layout

        // Vinculación de elementos con sus IDs
        etInput = findViewById(R.id.etInput);
        rgType = findViewById(R.id.rgType);
        tvResult = findViewById(R.id.tvResult);
        Button btnCalculate = findViewById(R.id.btnCalculate);
        Button btnClear = findViewById(R.id.btnClear);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnShow = findViewById(R.id.btnShow);

        // Asignación de acciones a los botones
        btnCalculate.setOnClickListener(v -> calculate());
        btnClear.setOnClickListener(v -> clear());
        btnSave.setOnClickListener(v -> save());
        btnShow.setOnClickListener(v -> show());
    }

    @SuppressLint({"SetTextI18n", "DefaultLocale"})
    private void calculate() {
        // Obtiene el valor introducido
        String inputStr = etInput.getText().toString().trim();
        if (inputStr.isEmpty()) {
            etInput.setError(getString(R.string.error_empty_input)); // Mensaje en el campo
            return;
        }

        double value;
        try {
            value = Double.parseDouble(inputStr); // Converter texto a número
        } catch (NumberFormatException e) {
            etInput.setError(getString(R.string.error_invalid_number));
            return;
        }

        double result = 0;
        String label = "";

        // Determina qué RadioButton está seleccionado
        int selectedId = rgType.getCheckedRadioButtonId();
        if (selectedId == R.id.rbLength || selectedId == R.id.rbWeight) {
            result = value / 1000.0; // Conversión común
            label = (selectedId == R.id.rbLength) ? "m → km" : "g → kg";
        } else if (selectedId == R.id.rbTemp) {
            result = (value * 9.0 / 5.0) + 32.0; // Celsius → Fahrenheit
            label = "°C → °F";
        }

        // Muestra el resultado
        tvResult.setText(getString(R.string.result_label,
                String.format("%.4f", result), label));
    }

    private void clear() {
        // Limpia campos y reinicia selección
        etInput.setText("");
        tvResult.setText(getString(R.string.result_default));
        rgType.check(R.id.rbLength);
    }

    private void save() {
        // Guarda el resultado actual
        String content = tvResult.getText().toString();
        if (content.contains("—")) {
            Toast.makeText(this, getString(R.string.error_no_conversion), Toast.LENGTH_SHORT).show();
            return;
        }
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_LAST, content).apply();
        Toast.makeText(this, getString(R.string.toast_saved), Toast.LENGTH_SHORT).show();
    }

    private void show() {
        // Recupera el último resultado guardado
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String saved = prefs.getString(KEY_LAST, null);
        if (saved == null) {
            Toast.makeText(this, getString(R.string.error_no_saved), Toast.LENGTH_SHORT).show();
        } else {
            tvResult.setText(saved);
            Toast.makeText(this, getString(R.string.toast_recovered), Toast.LENGTH_SHORT).show();
        }
    }
}
